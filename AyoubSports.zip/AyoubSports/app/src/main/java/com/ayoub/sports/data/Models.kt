package com.ayoub.sports.data

// football-data.org
data class MatchesResponse(val matches: List<ApiMatch>?)
data class ApiMatch(
    val id: Int?, val utcDate: String, val status: String?,
    val competition: ApiComp?, val homeTeam: ApiTeam?, val awayTeam: ApiTeam?, val score: ApiScore?
)
data class ApiComp(val code: String?, val name: String?, val emblem: String?)
data class ApiTeam(val id: Int?, val name: String?, val shortName: String?, val crest: String?)
data class ApiScore(val fullTime: ApiGoals?)
data class ApiGoals(val home: Int?, val away: Int?)

data class StandingsResponse(val competition: ApiComp?, val standings: List<StandingGroup>?)
data class StandingGroup(val type: String?, val table: List<StandingRow>?)
data class StandingRow(
    val position: Int?, val team: ApiTeam?, val playedGames: Int?,
    val won: Int?, val draw: Int?, val lost: Int?, val points: Int?, val goalDifference: Int?
)

// newsapi.org
data class NewsResponse(val articles: List<Article>?)
data class Article(
    val title: String?, val description: String?, val url: String?,
    val urlToImage: String?, val publishedAt: String?, val source: ArticleSource?
)
data class ArticleSource(val name: String?)
