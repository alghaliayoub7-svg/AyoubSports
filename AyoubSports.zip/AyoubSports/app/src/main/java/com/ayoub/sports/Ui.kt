@file:OptIn(ExperimentalMaterial3Api::class)

package com.ayoub.sports

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.ImageLoader
import coil.compose.AsyncImage
import com.ayoub.sports.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

val Bg = Color(0xFF070913)
val Card = Color(0xFF111827)
val Head = Color(0xFF1F2937)
val Acc = Color(0xFF00E676)
val Tx2 = Color(0xFF9CA3AF)
val Live = Color(0xFFFF3D00)

val LocalLoader = staticCompositionLocalOf<ImageLoader> { error("ImageLoader missing") }

@Composable
fun SportsTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Acc, onPrimary = Bg, background = Bg, surface = Card,
            onBackground = Color.White, onSurface = Color.White, surfaceVariant = Head
        ),
        content = content
    )
}

val COMP_NAMES = mapOf(
    "CL" to "دوري أبطال أوروبا", "EL" to "الدوري الأوروبي", "UECL" to "دوري المؤتمر الأوروبي",
    "PL" to "الدوري الإنجليزي الممتاز", "PD" to "الدوري الإسباني", "SA" to "الدوري الإيطالي",
    "BL1" to "الدوري الألماني", "FL1" to "الدوري الفرنسي"
)
val ORDER = listOf("CL", "EL", "UECL", "PL", "PD", "SA", "BL1", "FL1")

@Composable
fun Img(url: String?, size: Dp, modifier: Modifier = Modifier) {
    AsyncImage(
        model = url, imageLoader = LocalLoader.current, contentDescription = null,
        modifier = modifier.size(size), contentScale = ContentScale.Fit
    )
}

@Composable
fun Loading() = Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
    CircularProgressIndicator(color = Acc)
}

@Composable
fun ErrorBox(msg: String, retry: () -> Unit) = Column(
    Modifier.fillMaxSize().padding(24.dp),
    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
) {
    Text(msg, color = Tx2, textAlign = TextAlign.Center)
    Spacer(Modifier.height(12.dp))
    Button(onClick = retry) { Text("إعادة المحاولة") }
}

@Composable
fun Root(vm: AppVm = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    val items = listOf("المباريات" to "📊", "الدوريات" to "🏆", "الأخبار" to "📰", "حسابي" to "👤")
    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Card) {
                items.forEachIndexed { i, (t, e) ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Text(e, fontSize = 18.sp) }, label = { Text(t, fontSize = 11.sp) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> MatchesScreen(vm)
                1 -> LeaguesScreen(vm)
                2 -> NewsScreen(vm)
                else -> AccountScreen()
            }
        }
    }
}

// ---------------- المباريات ----------------
@Composable
fun MatchesScreen(vm: AppVm) {
    val day by vm.day.collectAsState()
    val st by vm.matches.collectAsState()
    var live by remember { mutableStateOf(false) }

    LaunchedEffect(day) {
        vm.loadMatches()
        while (true) { delay(60_000); vm.loadMatches(silent = true) } // تحديث تلقائي كل دقيقة
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(Card).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { vm.shift(-1) }) { Text("›", fontSize = 22.sp) }
            val fmt = DateTimeFormatter.ofPattern("EEEE d MMMM", Locale("ar"))
            Text(
                (if (day == LocalDate.now()) "اليوم - " else "") + day.format(fmt),
                Modifier.weight(1f), textAlign = TextAlign.Center, color = Acc, fontWeight = FontWeight.Bold
            )
            TextButton(onClick = { vm.shift(1) }) { Text("‹", fontSize = 22.sp) }
            FilterChip(selected = live, onClick = { live = !live }, label = { Text("Live") })
        }
        when (val s = st) {
            is UiState.Loading -> Loading()
            is UiState.Err -> ErrorBox(s.msg) { vm.loadMatches() }
            is UiState.Ok -> {
                val all = if (live) s.v.filter { it.status == "IN_PLAY" || it.status == "PAUSED" } else s.v
                val groups = ORDER.mapNotNull { c ->
                    val g = all.filter { it.competition?.code == c }.sortedBy { it.utcDate }
                    if (g.isEmpty()) null else c to g // الدوري الذي ما فيه مباريات يختفي
                }
                if (groups.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(if (live) "لا توجد مباريات مباشرة الآن" else "لا توجد مباريات في هذا اليوم", color = Tx2)
                    }
                } else LazyColumn(Modifier.fillMaxSize()) {
                    groups.forEach { (code, g) ->
                        item {
                            Row(
                                Modifier.fillMaxWidth().padding(top = 10.dp).background(Head).padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Img(g[0].competition?.emblem, 22.dp, Modifier.clip(RoundedCornerShape(5.dp)).background(Color.White).padding(2.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(COMP_NAMES[code] ?: g[0].competition?.name ?: code, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                        items(g) { MatchRow(it) }
                    }
                }
            }
        }
    }
}

@Composable
fun TeamSide(t: ApiTeam?, modifier: Modifier) = Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
    Img(t?.crest, 38.dp)
    Spacer(Modifier.height(4.dp))
    Text(
        t?.shortName ?: t?.name ?: "", fontSize = 11.sp, fontWeight = FontWeight.Bold,
        maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
    )
}

@Composable
fun MatchRow(m: ApiMatch) {
    val time = Instant.parse(m.utcDate).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("HH:mm"))
    val h = m.score?.fullTime?.home
    val a = m.score?.fullTime?.away
    Row(Modifier.fillMaxWidth().background(Card).padding(horizontal = 10.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        TeamSide(m.homeTeam, Modifier.weight(1f))
        Column(Modifier.width(80.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            when (m.status) {
                "IN_PLAY", "PAUSED" -> { Text("● مباشر", color = Live, fontSize = 10.sp); Score(h, a) }
                "FINISHED" -> { Text("انتهت", color = Tx2, fontSize = 10.sp); Score(h, a) }
                else -> Text(time, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }
        TeamSide(m.awayTeam, Modifier.weight(1f))
    }
    HorizontalDivider(color = Color(0x14FFFFFF))
}

@Composable
fun Score(h: Int?, a: Int?) = Text(
    "${h ?: 0} - ${a ?: 0}", color = Acc, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp,
    modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(Color(0xFF030712)).padding(horizontal = 8.dp, vertical = 3.dp)
)

// ---------------- الدوريات والترتيب ----------------
@Composable
fun LeaguesScreen(vm: AppVm) {
    val codes = listOf("PL", "PD", "SA", "BL1", "FL1", "CL")
    var sel by remember { mutableStateOf("PL") }
    val st by vm.standings.collectAsState()
    LaunchedEffect(sel) { vm.loadStandings(sel) }

    Column(Modifier.fillMaxSize()) {
        LazyRow(contentPadding = PaddingValues(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(codes) { c ->
                FilterChip(selected = sel == c, onClick = { sel = c }, label = { Text(COMP_NAMES[c] ?: c, fontSize = 12.sp) })
            }
        }
        when (val s = st) {
            is UiState.Loading -> Loading()
            is UiState.Err -> ErrorBox(s.msg) { vm.loadStandings(sel) }
            is UiState.Ok -> {
                val groups = s.v.standings.orEmpty()
                val table = (groups.firstOrNull { it.type == "TOTAL" } ?: groups.firstOrNull())?.table.orEmpty()
                LazyColumn(Modifier.fillMaxSize()) {
                    item {
                        Row(Modifier.fillMaxWidth().background(Head).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Img(s.v.competition?.emblem, 30.dp, Modifier.clip(RoundedCornerShape(6.dp)).background(Color.White).padding(3.dp))
                            Spacer(Modifier.width(10.dp))
                            Text("${COMP_NAMES[sel] ?: sel} - ترتيب الفرق", fontWeight = FontWeight.Bold)
                        }
                        Row(Modifier.fillMaxWidth().background(Card).padding(horizontal = 10.dp, vertical = 8.dp)) {
                            Text("#", Modifier.width(26.dp), color = Tx2, fontSize = 11.sp, textAlign = TextAlign.Center)
                            Text("الفريق", Modifier.weight(1f).padding(start = 34.dp), color = Tx2, fontSize = 11.sp)
                            listOf("لعب", "ف", "ت", "خ", "فارق", "نقاط").forEach {
                                Text(it, Modifier.width(34.dp), color = Tx2, fontSize = 11.sp, textAlign = TextAlign.Center)
                            }
                        }
                    }
                    items(table) { r ->
                        val me = r.team?.shortName == "Barcelona" || r.team?.name == "FC Barcelona"
                        Row(
                            Modifier.fillMaxWidth().background(if (me) Color(0x2200E676) else Card).padding(horizontal = 10.dp, vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${r.position ?: ""}", Modifier.width(26.dp), textAlign = TextAlign.Center, fontSize = 12.sp)
                            Img(r.team?.crest, 22.dp)
                            Spacer(Modifier.width(8.dp))
                            Text(r.team?.shortName ?: r.team?.name ?: "", Modifier.weight(1f), fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            listOf(r.playedGames, r.won, r.draw, r.lost, r.goalDifference).forEach {
                                Text("${it ?: 0}", Modifier.width(34.dp), textAlign = TextAlign.Center, fontSize = 12.sp)
                            }
                            Text("${r.points ?: 0}", Modifier.width(34.dp), textAlign = TextAlign.Center, fontSize = 13.sp, color = Acc, fontWeight = FontWeight.ExtraBold)
                        }
                        HorizontalDivider(color = Color(0x14FFFFFF))
                    }
                }
            }
        }
    }
}

// ---------------- الأخبار بالصور ----------------
@Composable
fun NewsScreen(vm: AppVm) {
    val topics = listOf("كرة القدم", "برشلونة", "دوري أبطال أوروبا")
    var sel by remember { mutableIntStateOf(0) }
    val st by vm.news.collectAsState()
    val uri = LocalUriHandler.current
    LaunchedEffect(sel) { vm.loadNews(topics[sel]) }

    Column(Modifier.fillMaxSize()) {
        LazyRow(contentPadding = PaddingValues(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(topics) { i, t -> FilterChip(selected = sel == i, onClick = { sel = i }, label = { Text(t) }) }
        }
        when (val s = st) {
            is UiState.Loading -> Loading()
            is UiState.Err -> ErrorBox(s.msg) { vm.loadNews(topics[sel]) }
            is UiState.Ok -> if (s.v.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("لا توجد أخبار", color = Tx2) }
            } else LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(s.v) { a ->
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Card)
                            .clickable { a.url?.let { uri.openUri(it) } }
                    ) {
                        if (!a.urlToImage.isNullOrBlank()) {
                            AsyncImage(
                                model = a.urlToImage, imageLoader = LocalLoader.current, contentDescription = null,
                                modifier = Modifier.fillMaxWidth().height(180.dp), contentScale = ContentScale.Crop
                            )
                        }
                        Column(Modifier.padding(14.dp)) {
                            Text("${a.source?.name ?: ""}  •  ${a.publishedAt?.take(10) ?: ""}", color = Acc, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(4.dp))
                            Text(a.title ?: "", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            if (!a.description.isNullOrBlank()) {
                                Spacer(Modifier.height(6.dp))
                                Text(a.description, color = Tx2, fontSize = 12.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------- الحساب ----------------
@Composable
fun Picker(label: String, value: String, items: List<String>, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Column {
        Text(label, color = Tx2, fontSize = 11.sp)
        Box {
            OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) { Text(value) }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                items.forEach { DropdownMenuItem(text = { Text(it) }, onClick = { onPick(it); open = false }) }
            }
        }
    }
}

@Composable
fun AccountScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val acc by ctx.accountFlow().collectAsState(initial = Account())
    var name by remember(acc) { mutableStateOf(acc.name) }
    var email by remember(acc) { mutableStateOf(acc.email) }
    var country by remember(acc) { mutableStateOf(acc.country) }
    var lang by remember(acc) { mutableStateOf(acc.lang) }
    var msg by remember { mutableStateOf("") }
    val countries = listOf("ليبيا", "تونس", "الجزائر", "مصر", "المغرب", "السعودية", "الإمارات", "قطر", "أخرى")
    val langs = listOf("العربية", "English", "Français")

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(if (acc.exists) "👋 أهلاً ${acc.name}" else "إنشاء حساب جديد", color = Acc, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        OutlinedTextField(name, { name = it }, label = { Text("الاسم") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(email, { email = it }, label = { Text("البريد الإلكتروني") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Picker("البلد", country, countries) { country = it }
        Picker("اللغة", lang, langs) { lang = it }
        Button(
            onClick = {
                if (name.isBlank()) { msg = "اكتب اسمك أولاً"; return@Button }
                scope.launch { ctx.saveAccount(Account(name.trim(), email.trim(), country, lang, true)); msg = "✅ تم الحفظ" }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (acc.exists) "حفظ التغييرات" else "إنشاء الحساب") }
        if (acc.exists) OutlinedButton(
            onClick = { scope.launch { ctx.clearAccount(); msg = "تم تسجيل الخروج" } },
            modifier = Modifier.fillMaxWidth()
        ) { Text("تسجيل الخروج") }
        if (msg.isNotEmpty()) Text(msg, color = Acc, fontSize = 12.sp)
        Text("الحساب محفوظ على جهازك فقط. الحساب السحابي الحقيقي يحتاج سيرفر.", color = Tx2, fontSize = 10.sp)
    }
}
