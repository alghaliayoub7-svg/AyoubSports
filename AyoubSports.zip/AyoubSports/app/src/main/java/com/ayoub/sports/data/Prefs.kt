package com.ayoub.sports.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.ds by preferencesDataStore("account")

private object K {
    val name = stringPreferencesKey("name")
    val email = stringPreferencesKey("email")
    val country = stringPreferencesKey("country")
    val lang = stringPreferencesKey("lang")
}

data class Account(
    val name: String = "", val email: String = "",
    val country: String = "ليبيا", val lang: String = "العربية", val exists: Boolean = false
)

fun Context.accountFlow(): Flow<Account> = ds.data.map { p ->
    Account(
        p[K.name] ?: "", p[K.email] ?: "",
        p[K.country] ?: "ليبيا", p[K.lang] ?: "العربية", p[K.name] != null
    )
}

suspend fun Context.saveAccount(a: Account) {
    ds.edit { it[K.name] = a.name; it[K.email] = a.email; it[K.country] = a.country; it[K.lang] = a.lang }
}

suspend fun Context.clearAccount() { ds.edit { it.clear() } }
