package com.ayoub.sports.data

import com.ayoub.sports.BuildConfig
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface FootballApi {
    @GET("v4/matches")
    suspend fun matches(
        @Query("dateFrom") from: String,
        @Query("dateTo") to: String,
        @Query("competitions") comps: String
    ): MatchesResponse

    @GET("v4/competitions/{code}/standings")
    suspend fun standings(@Path("code") code: String): StandingsResponse
}

interface NewsApi {
    @GET("v2/everything")
    suspend fun news(
        @Query("q") q: String,
        @Query("language") lang: String = "ar",
        @Query("sortBy") sort: String = "publishedAt",
        @Query("pageSize") size: Int = 30,
        @Query("apiKey") key: String
    ): NewsResponse
}

object Net {
    private val footballClient = OkHttpClient.Builder()
        .addInterceptor { c ->
            c.proceed(c.request().newBuilder().header("X-Auth-Token", BuildConfig.FOOTBALL_KEY).build())
        }.build()

    val football: FootballApi = Retrofit.Builder()
        .baseUrl("https://api.football-data.org/")
        .client(footballClient)
        .addConverterFactory(GsonConverterFactory.create())
        .build().create(FootballApi::class.java)

    val news: NewsApi = Retrofit.Builder()
        .baseUrl("https://newsapi.org/")
        .addConverterFactory(GsonConverterFactory.create())
        .build().create(NewsApi::class.java)
}
