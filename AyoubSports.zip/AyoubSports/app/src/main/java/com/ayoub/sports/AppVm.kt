package com.ayoub.sports

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ayoub.sports.data.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import retrofit2.HttpException
import java.io.IOException
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

sealed interface UiState<out T> {
    object Loading : UiState<Nothing>
    data class Ok<T>(val v: T) : UiState<T>
    data class Err(val msg: String) : UiState<Nothing>
}

// الدوري الأوروبي (EL) والمؤتمر (UECL) غير متاحين في الخطة المجانية. أضف أكوادهم هنا لو خطتك تدعمهم.
const val COMPS = "CL,PL,PD,SA,BL1,FL1"

class AppVm(app: Application) : AndroidViewModel(app) {
    val day = MutableStateFlow(LocalDate.now())
    val matches = MutableStateFlow<UiState<List<ApiMatch>>>(UiState.Loading)
    val standings = MutableStateFlow<UiState<StandingsResponse>>(UiState.Loading)
    val news = MutableStateFlow<UiState<List<Article>>>(UiState.Loading)

    fun shift(n: Long) { day.value = day.value.plusDays(n) }

    private fun msg(e: Exception): String = when (e) {
        is HttpException -> when (e.code()) {
            429 -> "تجاوزت حد الطلبات، انتظر دقيقة وحاول مرة ثانية"
            401, 403 -> "المفتاح غير صحيح أو خطتك لا تشمل هذه المسابقة"
            else -> "خطأ من الخادم (${e.code()})"
        }
        is IOException -> "تعذر الاتصال، تأكد من الإنترنت"
        else -> "حدث خطأ غير متوقع"
    }

    fun loadMatches(silent: Boolean = false) {
        if (BuildConfig.FOOTBALL_KEY.isBlank()) {
            matches.value = UiState.Err("ضع FOOTBALL_KEY في ملف local.properties"); return
        }
        viewModelScope.launch {
            if (!silent) matches.value = UiState.Loading
            try {
                val d = day.value
                val r = Net.football.matches(d.minusDays(1).toString(), d.plusDays(1).toString(), COMPS)
                val zone = ZoneId.systemDefault()
                // نطلب يوم قبل ويوم بعد ثم نفلتر بتاريخ جهازك المحلي
                val list = r.matches.orEmpty().filter {
                    Instant.parse(it.utcDate).atZone(zone).toLocalDate() == d
                }
                matches.value = UiState.Ok(list)
            } catch (e: Exception) {
                if (!silent) matches.value = UiState.Err(msg(e))
            }
        }
    }

    fun loadStandings(code: String) {
        if (BuildConfig.FOOTBALL_KEY.isBlank()) {
            standings.value = UiState.Err("ضع FOOTBALL_KEY في ملف local.properties"); return
        }
        viewModelScope.launch {
            standings.value = UiState.Loading
            try { standings.value = UiState.Ok(Net.football.standings(code)) }
            catch (e: Exception) { standings.value = UiState.Err(msg(e)) }
        }
    }

    fun loadNews(q: String) {
        if (BuildConfig.NEWS_KEY.isBlank()) {
            news.value = UiState.Err("ضع NEWS_KEY في ملف local.properties"); return
        }
        viewModelScope.launch {
            news.value = UiState.Loading
            try {
                val r = Net.news.news(q = q, key = BuildConfig.NEWS_KEY)
                news.value = UiState.Ok(r.articles.orEmpty().filter { !it.title.isNullOrBlank() })
            } catch (e: Exception) { news.value = UiState.Err(msg(e)) }
        }
    }
}
