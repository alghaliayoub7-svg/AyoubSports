package com.ayoub.sports

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import coil.ImageLoader
import coil.decode.SvgDecoder

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // شعارات الفرق والدوريات غالبا SVG، لذلك نضيف SvgDecoder
        val loader = ImageLoader.Builder(this)
            .components { add(SvgDecoder.Factory()) }
            .crossfade(true).build()
        setContent {
            SportsTheme {
                CompositionLocalProvider(
                    LocalLoader provides loader,
                    LocalLayoutDirection provides LayoutDirection.Rtl
                ) { Root() }
            }
        }
    }
}
